<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    require_once "inc/conn.inc.php";

    
    if(isset($_POST["username"]) && isset($_POST["password"]) && isset($_POST["first_name"]) && isset($_POST["last_name"]) && isset($_POST["user_role"])){
        
        // Getting the correct case for both names so it presents well in the DB
        $fName = ucwords(strtolower($_POST['first_name'])); 
        $lName = ucwords(strtolower($_POST['last_name']));
        $username = $_POST['username'];
        $password = $_POST['password'];
        $role = $_POST['user_role'];

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        if($role == "administrator"){
            $sql = "INSERT INTO user_data (username, password, firstname, lastname, is_admin, is_manager, is_operator, is_auditor) VALUES (?, ?, ?, ?, 1, 0, 0, 0);";
            $statement = mysqli_stmt_init($conn);
            mysqli_stmt_prepare($statement, $sql);
            mysqli_stmt_bind_param($statement, 'ssss', $username, $hashed_password, $fName, $lName);
            if (mysqli_stmt_execute($statement)) {
                header("location: menu-admin.php?status=registration-success");
                exit();
            } else {
                die("Error executing query: " . mysqli_error($conn));
            }
        }
        else if($role == "operator"){
            $sql = "INSERT INTO user_data (username, password, firstname, lastname, is_admin, is_manager, is_operator, is_auditor) VALUES (?, ?, ?, ?, 0, 0, 1, 0);";
            $statement = mysqli_stmt_init($conn);
            mysqli_stmt_prepare($statement, $sql);
            mysqli_stmt_bind_param($statement, 'ssss', $username, $hashed_password, $fName, $lName);
            if (mysqli_stmt_execute($statement)) {
                header("location: menu-admin.php?status=registration-success");
                exit();
            } else {
                die("Error executing query: " . mysqli_error($conn));
            }
        }
        else if($role == "manager"){
            $sql = "INSERT INTO user_data (username, password, firstname, lastname, is_admin, is_manager, is_operator, is_auditor) VALUES (?, ?, ?, ?, 0, 1, 0, 0);";
            $statement = mysqli_stmt_init($conn);
            mysqli_stmt_prepare($statement, $sql);
            mysqli_stmt_bind_param($statement, 'ssss', $username, $hashed_password, $fName, $lName);
            if (mysqli_stmt_execute($statement)) {
                header("location: menu-admin.php?status=registration-success");
                exit();
            } else {
                die("Error executing query: " . mysqli_error($conn));
            }
        }
        else if($role == "auditor"){
            $sql = "INSERT INTO user_data (username, password, firstname, lastname, is_admin, is_manager, is_operator, is_auditor) VALUES (?, ?, ?, ?, 0, 0, 0, 1);";
            $statement = mysqli_stmt_init($conn);
            mysqli_stmt_prepare($statement, $sql);
            mysqli_stmt_bind_param($statement, 'ssss', $username, $hashed_password, $fName, $lName);
            if (mysqli_stmt_execute($statement)) {
                header("location: menu-admin.php?status=registration-success");
                exit();
            } else {
                die("Error executing query: " . mysqli_error($conn));
            }
        }
        
        
       
    }

    mysqli_close($conn);

?>