<?php

require_once "inc/conn.inc.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (!empty($_POST["job_name_change"]) && !empty($_POST["job_code_change"]) && !empty($_POST["job_description_change"])) {
        $sql = "UPDATE jobs SET name=?, job_code=?, description=? WHERE name=?";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql); 
        mysqli_stmt_bind_param($statement, 'ssss', $_POST["job_name_change"], $_POST["job_code_change"], $_POST["job_description_change"], $_POST["job_name"]);
        if (mysqli_stmt_execute($statement)) {
            header("location: jobs.php?status=adjust-success"); 
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
    }

    if (!empty($_POST["job_name_change"]) && !empty($_POST["job_code_change"]) && empty($_POST["job_description_change"])) {
        $sql = "UPDATE jobs SET name=?, job_code=? WHERE name=?";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql); 
        mysqli_stmt_bind_param($statement, 'sss', $_POST["job_name_change"], $_POST["job_code_change"], $_POST["job_name"]);
        if (mysqli_stmt_execute($statement)) {
            header("location: jobs.php?status=adjust-success"); 
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
    }

    if (!empty($_POST["job_name_change"]) && !empty($_POST["job_description_change"]) && empty($_POST["job_code_change"])) {
        $sql = "UPDATE jobs SET name=?, description=? WHERE name=?";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql); 
        mysqli_stmt_bind_param($statement, 'sss', $_POST["job_name_change"], $_POST["job_description_change"], $_POST["job_name"]);
        if (mysqli_stmt_execute($statement)) {
            header("location: jobs.php?status=adjust-success"); 
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
    }

    if (!empty($_POST["job_code_change"]) && !empty($_POST["job_description_change"]) && empty($_POST["job_name_change"])) {
        $sql = "UPDATE jobs SET job_code=?, description=? WHERE name=?";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql); 
        mysqli_stmt_bind_param($statement, 'sss', $_POST["job_code_change"], $_POST["job_description_change"], $_POST["job_name"]);
        if (mysqli_stmt_execute($statement)) {
            header("location: jobs.php?status=adjust-success"); 
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
    }

    if (!empty($_POST["job_name_change"]) && empty($_POST["job_code_change"]) && empty($_POST["job_description_change"])) {
        $sql = "UPDATE jobs SET name=? WHERE name=?";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql); 
        mysqli_stmt_bind_param($statement, 'ss', $_POST["job_name_change"], $_POST["job_name"]);
        if (mysqli_stmt_execute($statement)) {
            header("location: jobs.php?status=adjust-success"); 
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
    }

    if (!empty($_POST["job_code_change"]) && empty($_POST["job_name_change"]) && empty($_POST["job_description_change"])) {
        $sql = "UPDATE jobs SET job_code=? WHERE name=?";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql); 
        mysqli_stmt_bind_param($statement, 'ss', $_POST["job_code_change"], $_POST["job_name"]);
        if (mysqli_stmt_execute($statement)) {
            header("location: jobs.php?status=adjust-success"); 
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
    }

    if (!empty($_POST["job_description_change"]) && empty($_POST["job_name_change"]) && empty($_POST["job_code_change"])) {
        $sql = "UPDATE jobs SET description=? WHERE name=?";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql); 
        mysqli_stmt_bind_param($statement, 'ss', $_POST["job_description_change"], $_POST["job_name"]);
        if (mysqli_stmt_execute($statement)) {
            header("location: jobs.php?status=adjust-success"); 
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
    }

    mysqli_close($conn);
}

?>
