<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Management</title>
    <link rel="stylesheet" href="styles/style.css"/>
</head>
<body>

<button id="menu_button" style="position: fixed; right: 20px; top: 20px; font-size: 30px; background-color: #007bff; color: #fff; border: black 2px solid; padding: 10px 20px; border-radius: 5px; cursor: pointer;">
    <a href="menu.php" style="color: #fff; text-decoration: none;">Back to Menu</a>
</button>

<?php
$status = isset($_GET['status']) ? $_GET['status'] : '';

if ($status == 'remove-success' || $status == 'adjust-success' || $status == 'add-success'): ?>
    <div style="color: green; font-size: 18px; padding: 10px; border: 1px solid green; background-color: #e0ffe0;">
        <?php 
        if ($status == 'remove-success') {
            echo 'Job successfully removed!';
        } elseif ($status == 'adjust-success') {
            echo 'Job successfully adjusted!';
        } elseif ($status == 'add-success') {
            echo 'Job successfully added!';
        }
        ?>
    </div>
    <script>
        setTimeout(function() {
            window.location.href = 'jobs.php';
        }, 3000);
    </script>
        <?php endif; ?>


    <h1>Job Management</h1>
    <div class="tom-table">
        <h3>List of Jobs</h3>
            <?php 
            require_once "C:/xampp/htdocs/www/WebSolution/inc/conn.inc.php";

            $sql = "SELECT job_code, assigned_to, name, description FROM jobs WHERE active=1 ORDER BY job_code ASC;";
            
            if ($result = mysqli_query($conn, $sql)){
                if(mysqli_num_rows($result) > 0){
                    echo "<table>
                            <tr>
                            <th>Job Code</th>
                            <th>Assigned To</th>
                            <th>Job Name</th>
                            <th>Job Description</th>
                            </tr>";
                    while ($row = mysqli_fetch_assoc($result)){
                        echo "<tr><td>$row[job_code]</td><td>$row[assigned_to]</td><td>$row[name]</td><td>$row[description]</td></tr>";
                    }
                    echo "</table>";

                    mysqli_free_result($result);

                }

            }
        
            ?>
    </div>

    <div class="tom-form">
        <h3>Add New Job</h3>
        <form action="add-job.php" method="post">
            <label for="job_name">Job Name:</label>
            <input type="text" id="job_name" name="job_name" placeholder="Enter new job name" required>
            <label for="job_code">Job Code:</label>
            <input type="text" id="job_code" name="job_code" placeholder="Enter job code" required>
            <label for="job_machine">Choose Machine:</label>
            <select id="job_machine" name="job_machine" required>
            <option value="" disabled selected>Choose a machine from the list</option>
                <?php   
                        require_once "C:/xampp/htdocs/www/WebSolution/inc/conn.inc.php";
                        $sql = "SELECT name FROM machines ORDER BY name ASC;";
                        if ($result = mysqli_query($conn, $sql)){
                            if(mysqli_num_rows($result) > 0){
                                while ($row = mysqli_fetch_assoc($result)){
                                    echo "<option value='{$row['name']}'>{$row['name']}</option>";
                                }
                                mysqli_free_result($result);
                            }
                            else {
                                echo "<option disabled>No machines found</option>";
                            }
                        }
                    
                ?>
            </select>
            <label for="job_operator">Assign Operator:</label>
            <select id="job_operator" name="job_operator" required>
            <option value="" disabled selected>Choose an operator</option>
                <?php   
                        require_once "C:/xampp/htdocs/www/WebSolution/inc/conn.inc.php";
                        $sql = "SELECT firstname, lastname FROM user_data WHERE is_operator=1 ORDER BY lastname ASC;";
                        if ($result = mysqli_query($conn, $sql)){
                            if(mysqli_num_rows($result) > 0){
                                while ($row = mysqli_fetch_assoc($result)){
                                    echo "<option value='{$row['firstname']} {$row['lastname']}'>{$row['firstname']} {$row['lastname']}</option>";
                                }
                                mysqli_free_result($result);
                            }
                            else {
                                echo "<option disabled>No operators found</option>";
                            }
                        }
                    
                ?>
            </select>
            <label for="job_description">Job Description:</label>
            <input type="textarea" id="job_description" name="job_description" placeholder="Enter a description of the job" required></textarea>
            <label for="job_button"></label>
            <input type="submit" id="job_button" value="Add Job">
        </form>
    </div>

    <div class="tom-form">
        <h3>Remove Job</h3>
        <form action="delete-job.php" method="post">
            <label for="job_name">Select Job to Remove:</label>
            <select id="job_name" name="job_name" required>
                <option value="" disabled selected>Click to show list of jobs</option>
            <?php   
                    require_once "C:/xampp/htdocs/www/WebSolution/inc/conn.inc.php";
                    $sql = "SELECT * FROM jobs WHERE active=1 ORDER BY name ASC;";
                    if ($result = mysqli_query($conn, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            while ($row = mysqli_fetch_assoc($result)){
                                echo "<option value='{$row['name']}'>{$row['name']}</option>";
                            }
                            mysqli_free_result($result);
                        }
                        else {
                            echo "<option disabled>No jobs found</option>";
                        }
                    }
                
            ?>
            </select>
            <label for="job_button"></label>
            <input type="submit" id="job_button" value="Remove Job">
        </form>
    </div>

    <div class="tom-form">
        <h3>Update Jobs</h3>
        <form id="adjust-job" action="adjust-job.php" method="post">
            <label for="job_name">Select Job to Update:</label>
            <select id="job_name" name="job_name" required>
                <option value="" disabled selected>Click to show job list</option>
            <?php   
                    require_once "C:/xampp/htdocs/www/WebSolution/inc/conn.inc.php";
                    $sql = "SELECT * FROM jobs WHERE active=1 ORDER BY name ASC;";
                    if ($result = mysqli_query($conn, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            while ($row = mysqli_fetch_assoc($result)){
                                echo "<option value='{$row['name']}'>{$row['name']}</option>";
                            }
                            mysqli_free_result($result);
                        }
                        else {
                            echo "<option disabled>No jobs found</option>";
                        }
                    }
        
            ?>
            </select>
            <label for="job_name_change">Adjust Name:</label>
            <input type="text" id="job_name_change" name="job_name_change" placeholder="Enter updated job name">

            <label for="job_code_change">Adjust Code:</label>
            <input type="text" id="job_code_change" name="job_code_change" placeholder="Enter updated job code">

            <label for="job_description_change">Adjust Description:</label>
            <input type="textarea" id="job_description_change" name="job_description_change" placeholder="Enter updated description of the job"></textarea>

            <label for="job_button"></label>
            <input type="submit" id="job_button" value="Confirm Job Adjustments">
        </form>
        <script defer>
            document.getElementById('adjust-job').addEventListener('submit', function(event) {
            // Using trim for whitespace removal in case manager were to enter a space in any field accidentally.
            var name = document.getElementById('job_name_change').value.trim();
            var code = document.getElementById('job_code_change').value.trim();
            var description = document.getElementById('job_description_change').value.trim();
                if (name == "" && description == "" && code == "") {
                    alert('Please make at least one adjustment (name, description, code, or all) before updating the job.');
                    event.preventDefault();
                    }
                }
            );
        </script>
    </div>
</body>
</html>