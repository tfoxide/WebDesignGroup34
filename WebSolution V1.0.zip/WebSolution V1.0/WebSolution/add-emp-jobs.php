<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Job to Employee Account</title>
    <link rel="stylesheet" href="styles/style.css"/>
</head>

<body>
<button id="menu_button" style="position: fixed; right: 20px; top: 20px; font-size: 30px; background-color: #007bff; color: #fff; border: black 2px solid; padding: 10px 20px; border-radius: 5px; cursor: pointer;">
    <a href="assign-jobs.php" style="color: #fff; text-decoration: none;">Back to Menu</a>
</button> 

<h1>Assign Jobs to Employee</h1>

<div class=tom-radiobtn>
<?php
// Database connection details
define("DB_HOST", "localhost");
define("DB_NAME", "factory_db");
define("DB_USER", "root");
define("DB_PASS", "");

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Validate username from GET
if (!isset($_GET['username'])) {
    echo "<p>Error: No employee selected!</p>";
    exit();
}
$username = $_GET['username'];
echo "<h3>Employee ID: " . htmlspecialchars($username) . "</h3>";

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if a job was selected
    if (!isset($_POST['jobs']) || empty($_POST['jobs'])) {
        //echo "<p>Error: No job selected. Please select a job and try again.</p>";
    } else {
        $jobId = $_POST['jobs'];

        // SQL query to update the job assigned to the user
        $sql = "UPDATE jobs SET assigned_to = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);

        // Check if the query prepared successfully
        if ($stmt === false) {
            die("Prepare failed: " . $conn->error);
        }

        // Bind parameters and execute
        $stmt->bind_param("si", $username, $jobId);

        if ($stmt->execute()) {
            // Redirect to avoid resubmission
            header("Location: add-emp-jobs.php?username=" . urlencode($username) . "&success=1");
            exit();
        } else {
            echo "<p>Error assigning job: " . $stmt->error . "</p>";
        }

        $stmt->close();
    }
}

// Fetch available jobs that are not assigned to any employee
$sql = "SELECT id, name FROM jobs WHERE assigned_to IS NULL";
$result = $conn->query($sql);
?>

<!-- HTML Form for Job Assignment -->
<form action="add-emp-jobs.php?username=<?php echo htmlspecialchars($username); ?>" method="POST">
    <label for="job">Select Job:</label>
    <select name="jobs" id="job" required>
        <option value="">--Select a Job--</option>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . htmlspecialchars($row['id']) . "'>" . htmlspecialchars($row['name']) . "</option>";
            }
        } else {
            echo "<option value=''>No available jobs</option>";
        }
        ?>
    </select>
    <input type="hidden" name="username" value="<?php echo htmlspecialchars($username); ?>">
    <button class="btn" type="submit">Assign Job</button>
</form>
    </div>
<?php
// Close connection
$conn->close();
?>
</body>
</html>
