<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Machine to Employee Account</title>
    <link rel="stylesheet" href="styles/style.css"/>
</head>

<body>
<button id="menu_button" style="position: fixed; right: 20px; top: 20px; font-size: 30px; background-color: #007bff; color: #fff; border: black 2px solid; padding: 10px 20px; border-radius: 5px; cursor: pointer;">
    <a href="assign-machines.php" style="color: #fff; text-decoration: none;">Back to Menu</a>
</button> 

<h1>Assign Machine to Employee</h1>

<div class=tom-dropdown>
<?php
// Database connection details
define("DB_HOST", "localhost");
define("DB_NAME", "factory_db");
define("DB_USER", "root");
define("DB_PASS", "");

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Validate username from GET
if (!isset($_GET['username'])) {
    echo "<p>Error: No employee selected!</p>";
    exit();
}
$username = $_GET['username'];
echo "<h3>Employee ID: " . htmlspecialchars($username) . "</h3>";

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if a machine was selected
    if (!isset($_POST['machines']) || empty($_POST['machines'])) {
        //echo "<p>Error: No machine selected. Please select a machine and try again.</p>";
    } else {
        $machineId = $_POST['machines'];

        // SQL query to update the machine assigned to the user
        $sql = "UPDATE machines SET current_operator = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);

        // Check if the query prepared successfully
        if ($stmt === false) {
            die("Prepare failed: " . $conn->error);
        }

        // Bind parameters and execute
        $stmt->bind_param("si", $username, $machineId);

        if ($stmt->execute()) {
            // Redirect to avoid resubmission
            header("Location: assign-machines.php?success=1");
            exit();
        } else {
            echo "<p>Error assigning machine: " . $stmt->error . "</p>";
        }

        $stmt->close();
    }
}

// Fetch available machines that are not assigned to any employee
$sql = "SELECT id, name FROM machines";
$result = $conn->query($sql);
?>

<!-- HTML Form for Machine Assignment -->
<form action="add-emp-machine.php?username=<?php echo htmlspecialchars($username); ?>" method="POST">
    
    <select name="machines" id="machine" required>
        <option value="">--Select a Machine--</option>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . htmlspecialchars($row['id']) . "'>" . htmlspecialchars($row['name']) . "</option>";
            }
        } else {
            echo "<option value=''>No available machines</option>";
        }
        ?>
    </select>
    <input type="hidden" name="username" value="<?php echo htmlspecialchars($username); ?>">
    <button class="btn" type="submit">Assign Machine</button>
</form>
    </div>
<?php
// Close connection
$conn->close();
?>
</body>
</html>
