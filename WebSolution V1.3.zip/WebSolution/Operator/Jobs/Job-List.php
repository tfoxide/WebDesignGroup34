<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../../Styles/diffstyle.css">
    <meta charset="UTF-8">
    <meta name="author" content="Xavier Curwood">
    <title>Job List</title>
</head>
<header>
    <h1>Job List</h1>
    <a href="../Operator-Home.php" id='back-button'>
        <button>Back</button>
    </a>
</header>
<body>
<?php
    session_start();
    require_once "../../inc/conn.inc.php";
    // Function to toggle status
    function toggleStatus($currentStatus) {
        if ($currentStatus == 'Paused') {
            return 'In Progress';
        } 
        elseif ($currentStatus == 'In Progress') {
            return 'Paused';
        }
        return $currentStatus;
    }

    //Check for toggle
    if (isset($_POST['toggle'])) {
        $code = $_POST['Code'];
        $currentStatus = $_POST['current_status'];
        $machine = $_POST['Machine'];

        $newStatus = toggleStatus($currentStatus);
        
        // Update the job status in the database
        $updateSql = "UPDATE jobs SET status='$newStatus' WHERE job_code='$code'";
        mysqli_query($conn, $updateSql);
    }

    // Get the current operator
    $operator = $_SESSION['username'];




$sql = "SELECT job_code, name, description, status, machine FROM jobs WHERE assigned_to='$operator';"; #TODO make assigneduser a variable and check for login

//find jobs for user
if ($result = mysqli_query($conn, $sql)) {
    if (mysqli_num_rows($result) > 0) {
        echo "<table>";
        echo 
        "<tr>
            <th id='number-column'>Code</th>
            <th>Name</th>
            <th>Details</th>
            <th>Status</th>
            <th>Machine</th>
            <th>Start/Stop</th>
            <th>Task Notes</th>
        </tr>";
        // Fetch each rows data
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td id='number-column'>" . $row["job_code"] . "</td>";
            echo "<td>" . $row["name"] . "</td>";
            echo "<td>" . $row["description"] . "</td>";
            echo "<td>" . $row["status"] . "</td>";
            echo "<td>" . $row["machine"] . "</td>";

            //create a start/stop button - change the status accordingly and make sure the machine matches whats required
            echo "  <td>
                        <form method='post' action=''>
                            <input type='hidden' name='Code' value='" . $row["job_code"] . "' />
                            <input type='hidden' name='current_status' value='" . $row["status"] . "' />
                            <input type='hidden' name='Machine' value='" . $row["machine"] . "' />
                            <button type='submit' name='toggle'>
                                " . ($row["status"] == 'In Progress' ? 'Pause' : 'Start') . "
                            </button>
                        </form>
                    </td>";
            //link to task notes
            echo "  <td>
                        <form action='../Task-Notes.php'>
                            <button type='submit'>Add</button>
                        </form>
                    </td>";
            echo "</tr>";
        }
        echo "</table>";
        mysqli_free_result($result);
    }
}

mysqli_close($conn);
    ?>
</body>
</html>