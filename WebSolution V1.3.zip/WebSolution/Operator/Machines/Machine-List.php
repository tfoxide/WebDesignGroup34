<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../../Styles/diffstyle.css">
    <meta charset="UTF-8">
    <meta name="author" content="Jarrah Eglinton">
    <title>Machine List</title>
</head>
<body>
    <header>
        <h1>Machine List</h1>
        <a href="../Operator-Home.php" id='back-button'>
            <button>Back</button>
        </a>
    </header>
    <?php
        session_start();
        require_once "../../inc/conn.inc.php";
        error_reporting(E_ALL);
        ini_set('display_errors', 1);

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        if (!isset($_SESSION['username'])) {
            echo "User not logged in.";
            exit();
        }

        // Handle the unassignment of a machine
        if (isset($_POST['delete'])) {
            $machineId = $_POST['machine_id'];

            // Update the current_operator to NULL (or any appropriate value)
            $updateSql = "UPDATE machines SET current_operator=NULL WHERE id='$machineId'";
            if (mysqli_query($conn, $updateSql)) {
                echo "Machine unassigned successfully.";
            } else {
                echo "Error unassigning machine: " . mysqli_error($conn);
            }
        }

        $operator = $_SESSION['username'];
        $sql = "SELECT id, name, description, current_operator, in_use FROM machines WHERE current_operator='$operator';";

        if ($result = mysqli_query($conn, $sql)) {
            if (mysqli_num_rows($result) > 0) {
                echo "<table>";
                echo 
                "<tr>
                    <th id='number-column'>Code</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Current Operator</th>
                    <th>In Use</th>
                    <th>Action</th>
                </tr>";

                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td id='number-column'>" . $row["id"] . "</td>";
                    echo "<td>" . $row["name"] . "</td>";
                    echo "<td>" . $row["description"] . "</td>";
                    echo "<td>" . $row["current_operator"] . "</td>";
                    echo "<td>" . $row["in_use"] . "</td>";
                    echo "<td>
                            <form method='post' action=''>
                                <input type='hidden' name='machine_id' value='" . $row["id"] . "' />
                                <button type='submit' name='delete'>Remove</button>
                            </form>
                          </td>";
                    echo "</tr>";
                }
                echo "</table>";
                mysqli_free_result($result);
            } else {
                echo "No machines found for the current operator.";
            }
        } else {
            echo "Error in query: " . mysqli_error($conn);
        }
        mysqli_close($conn);
    ?>
</body>
</html>
