<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../Styles/diffstyle.css">
    <meta charset="UTF-8">
    <meta name="author" content="Xavier Curwood">
    <title>Operator</title>
</head>
<header>
    <h1>Operator Menu</h1>
    <a href="http://127.0.0.1/www/WebSolution/login.php" id='back-button'><button>Logout</button></a>

</header>
<body>
    <div>
    <?php 
                session_start();
                include_once "C:/xampp/htdocs/www/WebSolution/inc/conn.inc.php";
                if (isset($_SESSION['username'])) {
                    $sql = "SELECT firstname FROM user_data WHERE username = ?;";
                    $statement = mysqli_stmt_init($conn);
                    mysqli_stmt_prepare($statement, $sql);
                    mysqli_stmt_bind_param($statement, 's', $_SESSION['username']);
                    mysqli_stmt_execute($statement);
                    $result = mysqli_stmt_get_result($statement);
                    $row = mysqli_fetch_assoc($result);

                    if ($row) {
                        echo "<h2 style='font-size: 34px; text-align: center;'>Welcome, " . htmlspecialchars($row['firstname']) . "</h2>";
                    }

                } 
            ?>
    </div>
    <table id="operator-menu">
        <tr>
            <th>Menu</th>
        </tr>
        <tr>
            <td>
                <a href="Jobs/Job-List.php">
                    <button id='base-button'>Jobs</button>
                </a>
                <a href="Machines/Machine-List.php">
                    <button id='base-button'>Machines</button>
                </a>
                <a href="Task-Notes.php">
                    <button id='base-button'>Task Notes</button>
                </a>
            </td>
    </table>
</body>
</html>