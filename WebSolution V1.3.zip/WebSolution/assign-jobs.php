<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Jobs to Operator Employee</title>
    <meta name="author" content="Jarrah Eglinton">
    <link rel="stylesheet" href="styles/style.css"/>
</head>

<body>
<button id="menu_button" style="position: fixed; right: 20px; top: 20px; font-size: 30px; background-color: #007bff; color: #fff; border: black 2px solid; padding: 10px 20px; border-radius: 5px; cursor: pointer;">
    <a href="menu.php" style="color: #fff; text-decoration: none;">Back to Menu</a>
</button>  

<h1>ADD JOBS TO EMPLOYEE ACCOUNT</h1>
<h3>EMPLOYEE ACCOUNTS</h3>

<div class="tom-table">
    <?php
        // Database connection details
        define("DB_HOST", "localhost");
        define("DB_NAME", "factory_db");
        define("DB_USER", "root");
        define("DB_PASS", "");

        // Create connection
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // SQL query to fetch employee details and their assigned jobs
        $sql = "SELECT user_data.firstname, user_data.lastname, user_data.username, user_data.datejoined, 
        user_data.is_operator, user_data.is_manager, user_data.is_auditor, user_data.is_admin, 
        user_data.status, jobs.name AS job_name 
        FROM user_data
        LEFT JOIN jobs ON user_data.username = jobs.assigned_to
        ORDER BY user_data.username";

        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {        
            // Output data of each row
            echo "<table border='0'>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Employee ID</th>
                        <th>Date Joined</th>
                        <th>Status</th>
                        <th>Assigned Job</th>
                        <th>Edit Jobs</th>
                    </tr>";
            while ($row = $result->fetch_assoc()) {
                // Format the date to DD/MM/YYYY
                $dateJoined = new DateTime($row["datejoined"]);
                $formattedDateJoined = $dateJoined->format('d/m/Y');

                // Output table data with a button for assigning/updating job
                echo "<tr>
                        <td>" . htmlspecialchars($row["firstname"]) . "</td>
                        <td>" . htmlspecialchars($row["lastname"]) . "</td>
                        <td>" . htmlspecialchars($row["username"]) . "</td>
                        <td>" . $formattedDateJoined . "</td>
                        <td>" . htmlspecialchars($row["status"]) . "</td>
                        <td>" . htmlspecialchars($row["job_name"] ?? 'No job assigned') . "</td>
                        <td>
                            <form action='add-emp-jobs.php?username=" . htmlspecialchars($row['username']) . "' method='POST'>
                                <button class='btn' type='submit'>✎</button>
                            </form>
                        </td>
                    </tr>";
            }
            echo "</table>";
        } else {
            echo "0 results";
        }

        // Close connection
        $conn->close();
    ?>
</div>
</body>
</html>
