<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Roles to Operator Employee: </title>
    <meta name="author" content="Jarrah Eglinton">
    <link rel="stylesheet" type="text/css" href="styles/style.css">
</head>

<body>
<button id="menu_button" style="position: fixed; right: 20px; top: 20px; font-size: 30px; background-color: #007bff; color: #fff; border: black 2px solid; padding: 10px 20px; border-radius: 5px; cursor: pointer;">
    <a href="menu.php" style="color: #fff; text-decoration: none;">Back to Menu</a>
</button>
    <h1>ADD ROLE TO EMPLOYEE ACCOUNT</h1>
    <h3>EMPLOYEE ACCOUNTS</h2>

<div class="tom-table">
    <?php
        // Database connection details
        define("DB_HOST", "localhost");
        define("DB_NAME", "factory_db");
        define("DB_USER", "root");
        define("DB_PASS", "");

        // Create connection
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // SQL query to fetch firstname, lastname, and roles
        $sql = "SELECT firstname, lastname, username, datejoined, is_operator, is_manager, is_auditor, is_admin, status FROM user_data";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output data of each row
            echo "<table border='0'><tr><th>First Name</th><th>Last Name</th><th>Employee I.D</th><th>Date Joined</th><th>Status</th><th>Role/s</th><th>Edit Role</th></tr>";
            while ($row = $result->fetch_assoc()) {
                // Initialize role string
                $role = '';

                // Format the date to DD/MM/YYYY
                $dateJoined = new DateTime($row["datejoined"]);
                $formattedDateJoined = $dateJoined->format('d/m/Y');

                // Check and append each role
                if ($row["is_operator"]) {
                    $role .= 'Operator, ';
                }
                if ($row["is_admin"]) {
                    $role .= 'Admin, ';
                }
                if ($row["is_manager"]) {
                    $role .= 'Manager, ';
                }
                if ($row["is_auditor"]) {
                    $role .= 'Auditor, ';
                }

                // Remove trailing comma and space
                $role = rtrim($role, ', ');

                // Output table data with a button for assigning/updating role
                echo "<tr>
                <td>" . $row["firstname"] . "</td>
                <td>" . $row["lastname"] . "</td>
                <td>" . $row["username"] . "</td>
                <td>" . $formattedDateJoined . "</td>
                <td>" . $row["status"] . "</td>
                <td>" . ($role ? $role : 'No Role Assigned') . "</td>
                <td>
                    <form action='add-emp-role.php' method='POST'>
                        <input type='hidden' name='username' value='" . $row["username"] . "'>
                        <button class='btn' type='submit'>✎</button>
                    </form>
                </td>
            </tr>";
            }
            echo "</table>";
        } else {
            echo "0 results";
        }

        // Close connection
        $conn->close();
    ?>
</div>
