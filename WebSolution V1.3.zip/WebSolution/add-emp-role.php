<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Role to Employee</title>
    <link rel="stylesheet" type="text/css" href="styles/style.css">
</head>

<body>
    <button id="menu_button" style="position: fixed; right: 20px; top: 20px; font-size: 30px; background-color: #007bff; color: #fff; border: black 2px solid; padding: 10px 20px; border-radius: 5px; cursor: pointer;">
        <a href="assign-roles.php" style="color: #fff; text-decoration: none;">Back to Menu</a>
    </button>   

    <h1>ASSIGN/UPDATE ROLE FOR EMPLOYEES</h1>

    <div class=tom-radiobtn>
    <?php
        // Database connection details
        define("DB_HOST", "localhost");
        define("DB_NAME", "factory_db");
        define("DB_USER", "root");
        define("DB_PASS", "");

        // Create connection
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Initialize variables
        $username = '';
        $is_operator = $is_manager = $is_auditor = $is_admin = 0;

        // Get the username from the POST request
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['username'])) {
            $username = $_POST['username'];

            // Fetch current roles
            $sql = "SELECT is_operator, is_manager, is_auditor, is_admin FROM user_data WHERE username = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $is_operator = $row['is_operator'];
                $is_manager = $row['is_manager'];
                $is_auditor = $row['is_auditor'];
                $is_admin = $row['is_admin'];
            } else {
                echo "No user found.";
                exit();
            }
            $stmt->close();
        } else {
            echo "Error with request";
            exit();
        }

        // Check if form is submitted to update roles
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_roles'])) {

            // Retrieves the checkbox values
            $is_operator = isset($_POST['is_operator']) ? 1 : 0;
            $is_manager = isset($_POST['is_manager']) ? 1 : 0;
            $is_auditor = isset($_POST['is_auditor']) ? 1 : 0;
            $is_admin = isset($_POST['is_admin']) ? 1 : 0;

            // Update roles in the database
            $sql = "UPDATE user_data SET is_operator = ?, is_manager = ?, is_auditor = ?, is_admin = ? WHERE username = ?";
            $stmt = $conn->prepare($sql);
            if ($stmt === false) {
                die("Prepare failed: " . $conn->error);
            }

            // Bind parameters
            $stmt->bind_param("iiiss", $is_operator, $is_manager, $is_auditor, $is_admin, $username);
            
            // Execute the update
            if ($stmt->execute()) {
                // Redirect to assign-roles.php after successful update
                header("Location: assign-roles.php");
                exit(); // Ensure script execution stops after the redirect
            } else {
                echo "<p>Error updating roles: " . $stmt->error . "</p>"; // More specific error messages
            }
            $stmt->close();
        }
            
    ?>

    <?php
        echo  "<br></br> <h2>Employee ID: " . htmlspecialchars($username) . "</h2>";
    ?>

    
    <h3>Current Roles:</h3>
        

    <form action="add-emp-role.php" method="POST">
        <input type="hidden" name="username" value="<?php echo htmlspecialchars($username); ?>">
        <label>
            <input type="checkbox" name="is_operator" value="1" <?php echo $is_operator ? 'checked' : ''; ?>>
            Operator
        </label><br>
        <label>
            <input type="checkbox" name="is_manager" value="1" <?php echo $is_manager ? 'checked' : ''; ?>>
            Manager
        </label><br>
        <label>
            <input type="checkbox" name="is_auditor" value="1" <?php echo $is_auditor ? 'checked' : ''; ?>>
            Auditor
        </label><br>
        <label>
            <input type="checkbox" name="is_admin" value="1" <?php echo $is_admin ? 'checked' : ''; ?>>
            Admin
        </label><br><br>
        
        <input type="submit" class="btn" name="update_roles" value="Update Roles">
    </form>
</div>
    <?php
    // Close connection
    $conn->close();
    ?>
</body>
</html>
