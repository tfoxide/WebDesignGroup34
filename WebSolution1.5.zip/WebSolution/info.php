<?php
echo ($fName = ucwords(strtolower($_POST['first_name'])));
echo "\n"; 
echo ($lName = ucwords(strtolower($_POST['last_name'])));
echo "\n";
echo ($username = $_POST['username']);
echo "\n"; 
echo ($password = $_POST['password']);
echo "\n";
echo ($role = $_POST['user_role']);
?>