<?php

require_once "inc/conn.inc.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {


    if (!empty($_POST["machine_name_change"]) && !empty($_POST["machine_description_change"])) {
        $sql = "UPDATE machines SET name=?, description=? WHERE name=?";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql); 
        mysqli_stmt_bind_param($statement, 'sss', $_POST["machine_name_change"], $_POST["machine_description_change"], $_POST["machine_name"]);
        if (mysqli_stmt_execute($statement)) {
            header("location: machines.php?status=adjust-success"); 
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
    }

    if (empty($_POST["machine_name_change"]) && !empty($_POST["machine_description_change"])) {
        $sql = "UPDATE machines SET description=? WHERE name=?";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql); 
        mysqli_stmt_bind_param($statement, 'ss', $_POST["machine_description_change"], $_POST["machine_name"]);
        if (mysqli_stmt_execute($statement)) {
            header("location: machines.php?status=adjust-success"); 
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
    }

    if (!empty($_POST["machine_name_change"]) && empty($_POST["machine_description_change"])) {
        $sql = "UPDATE machines SET name=? WHERE name=?";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql); 
        mysqli_stmt_bind_param($statement, 'ss', $_POST["machine_name_change"], $_POST["machine_name"]);
        if (mysqli_stmt_execute($statement)) {
            header("location: machines.php?status=adjust-success"); 
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
    }

    if (empty($_POST["machine_name_change"]) && empty($_POST["machine_description_change"])) {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
    }

    mysqli_close($conn);


?>
