<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles/style.css"/>
</head>
<body>
<?php
    $status = isset($_GET['status']) ? $_GET['status'] : '';

    if ($status == 'registration-success' || $status == 'adjust-success' || $status == 'role-success'): ?>
        <div style="color: green; font-size: 18px; padding: 10px; border: 1px solid green; background-color: #e0ffe0;">
            <?php 
            if ($status == 'registration-success') {
                echo 'User successfully registered!';
            } elseif ($status == 'adjust-success') {
                echo 'User details successfully adjusted!';
            } 
            ?>
        </div>
        <script>
            setTimeout(function() {
                window.location.href = 'menu-admin.php';
            }, 3000);
        </script>
<?php endif; ?>
    <h1>Administrator Menu</h1>
            <?php 
                session_start();
                include_once "C:/xampp/htdocs/www/WebSolution/inc/conn.inc.php";
                if (isset($_SESSION['username'])) {
                    $sql = "SELECT firstname FROM user_data WHERE username = ?;";
                    $statement = mysqli_stmt_init($conn);
                    mysqli_stmt_prepare($statement, $sql);
                    mysqli_stmt_bind_param($statement, 's', $_SESSION['username']);
                    mysqli_stmt_execute($statement);
                    $result = mysqli_stmt_get_result($statement);
                    $row = mysqli_fetch_assoc($result);

                    if ($row) {
                        echo "<h2 style='font-size: 34px; text-align: center;'>Welcome, " . htmlspecialchars($row['firstname']) . "</h2>";
                    }

                } 
            ?>
            <h2 style="text-align: center; font-size: 20px;"><a href="VIEW PAGE.php">Click here for 'view access' to the dashboard</a></h2>

            <div style="display: grid; grid-template-columns: 1fr auto 1fr; gap: 20px; align-items: center;">
                <div>
                <h2 style="text-align: left;">Register New User</h2>
                    <form onsubmit="return validatePassword()" action="reg-process.php" method="post">
                        <label for="first_name" style="font-weight: bold;">First Name:</label>
                        <input type="text" id="first_name" name="first_name" required>
                        <label for="last_name" style="font-weight: bold;">Last Name:</label>
                        <input type="text" id="last_name" name="last_name" required>
                        <label for="username" style="font-weight: bold;">Username:</label>
                        <input type="text" id="username" name="username" required>
                        <label for="password" style="font-weight: bold;">Password:</label>
                        <input type="password" id="password" name="password" required> 
                        <label for="confirm-password" style="font-weight: bold;">Confirm Password:</label>
                        <input type="password" id="confirm-password" name="confirm-password" required>
                        <label for="user_role" style="font-weight: bold;">User Role:</label>
                        <select id="user_role" name="user_role" required>
                            <option value="" disabled selected>Choose a role</option>
                            <option value="administrator">Administrator</option>
                            <option value="operator">Operator</option>
                            <option value="manager">Manager</option>
                            <option value="auditor">Auditor</option>
                        </select><br>
                        <button type="submit">Register</button>
                    </form>
                    <script defer>
                        function validatePassword(){
                            let password = document.getElementById("password").value;
                            let confirmPassword = document.getElementById("confirm-password").value;
                            if(password !== confirmPassword){
                                alert("Passwords do not match");
                                return false;
                            }
                            return true;
                        }
                    </script>
                </div>

                <div style="text-align: center; margin: 0 100px; font-weight: bold; font-size: 40px;">OR</div>

                <div>
                    <h2>Edit User Information</h2>
                    <form style="margin: right; text-align: left;" id="edit-form" action="adjust-user.php" method="post">
                        <label for="user">Select user:</label>
                        <select id="user" name="user" required>
                        <option value="" disabled selected>Choose a user</option>
                            <?php   
                                    require_once "C:/xampp/htdocs/www/WebSolution/inc/conn.inc.php";
                                    $sql = "SELECT * FROM user_data ORDER BY lastname ASC;";
                                    if ($result = mysqli_query($conn, $sql)){
                                        if(mysqli_num_rows($result) > 0){
                                            while ($row = mysqli_fetch_assoc($result)){
                                                if ($row['is_admin'] == '1') {
                                                    echo "<option value='{$row['firstname']} {$row['lastname']}'>{$row['firstname']} {$row['lastname']} (Administrator)</option>";
                                                }
                                                elseif ($row['is_manager'] == '1') {
                                                    echo "<option value='{$row['firstname']} {$row['lastname']}'>{$row['firstname']} {$row['lastname']} (Manager)</option>";
                                                }
                                                elseif ($row['is_operator'] == '1') {
                                                    echo "<option value='{$row['firstname']} {$row['lastname']}'>{$row['firstname']} {$row['lastname']} (Operator)</option>";
                                                }
                                                elseif ($row['is_auditor'] == '1') {
                                                    echo "<option value='{$row['firstname']} {$row['lastname']}'>{$row['firstname']} {$row['lastname']} (Auditor)</option>";
                                                }
                                                
                                            }
                                            mysqli_free_result($result);
                                        }
                                        else {
                                            echo "<option disabled>No users found</option>";
                                        }
                                    }
                                
                            ?>
                        </select>
                            <label for="fname">First Name:</label>
                            <input type="text" id="fname" name="fname">
                            <label for="lname">Last Name:</label>
                            <input type="text" id="lname" name="lname">
                            <label for="role">Role:</label>
                            <select id="role" name="role">
                                <option value="" disabled selected>Choose a role</option>
                                <option value="administrator">Administrator</option>
                                <option value="operator">Operator</option>
                                <option value="manager">Manager</option>
                                <option value="auditor">Auditor</option>
                            </select><br>
                        <button type="submit">Update User</button>
                    </form>
                    <script defer>
                        document.getElementById('edit-form').addEventListener('submit', function(event) {
                        var fname = document.getElementById('fname').value.trim();
                        var lname = document.getElementById('lname').value.trim();
                        var role = document.getElementById('role').value.trim();
                        // Using trim for whitespace removal in case manager were to enter a space in any field accidentally.
                            if (fname == '' && lname == '' && role == '') {
                                alert('Please make at least one adjustment (e.g. first name, role) before updating the user.');
                                event.preventDefault();
                                }
                            }
                        );
                    </script>
                </div>
            </div>  
</body>
</html>
