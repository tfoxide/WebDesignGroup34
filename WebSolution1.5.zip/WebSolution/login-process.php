<?php 
session_start();
require_once "inc/conn.inc.php";

    // First validating that the user has entered a username and password
    if(isset($_POST["username"]) && isset($_POST["password"])){
        require_once "inc/conn.inc.php";
        
        $sql = "SELECT * FROM user_data WHERE username=?;";
        $username = $_POST["username"];
        $password = $_POST["password"];

        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql); 
        mysqli_stmt_bind_param($statement, 's', $username);
        mysqli_stmt_execute($statement);
        $result = mysqli_stmt_get_result($statement);
        $row = mysqli_fetch_assoc($result);

        // Checking if the username exists in the database and if the password matches the hashed password.
        if(count($row) > 0 && password_verify($password, $row["password"])){
            // Replace the placeholder employee files with whatever html/php page you need to link to.
            echo "Login successful";
            $_SESSION['username'] = $row["username"];
            
            if($row["is_admin"] == 1){
                echo "Welcome admin";
                header("location: menu-admin.php");
            } 
            if($row["is_manager"] == 1){
                echo "Welcome manager";
                header("location: menu.php");
            }
            if($row["is_operator"] == 1){
                echo "Welcome operator";
                header("location: OPERATOR MENU TBA.php");
            }
            if($row["is_auditor"] == 1){
                echo "Welcome auditor";
                header("location: AUDITOR MENU TBA.php");
            }
            
        } 
        
        else {
            echo "Invalid username or password";
        }


        if(mysqli_connect_errno()){
            die("Failed to connect to the database: " . mysqli_connect_error());
        }

    }
    
    // Bit more backend validation
        if(empty($_POST["username"]) || empty($_POST["password"])){
            die("Please enter both a valid username and password");
        }

    mysqli_close($conn);
    
?>    

