<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Machine Management</title>
    <link rel="stylesheet" href="styles/style.css"/>
</head>
<body>

<button id="menu_button" style="position: fixed; right: 20px; top: 20px; font-size: 30px;"><a href="menu.php">Back to Menu</a></button>

<?php
$status = isset($_GET['status']) ? $_GET['status'] : '';


if ($status == 'remove-success' || $status == 'adjust-success' || $status == 'add-success'): ?>
    <div style="color: green; font-size: 18px; padding: 10px; border: 1px solid green; background-color: #e0ffe0;">
        <?php 
        if ($status == 'remove-success') {
            echo 'Machine successfully removed!';
        } elseif ($status == 'adjust-success') {
            echo 'Machine successfully adjusted!';
        } elseif ($status == 'add-success') {
            echo 'Machine successfully added!';
        }
        ?>
    </div>
    <script>
        setTimeout(function() {
            window.location.href = 'machines.php';
        }, 3000);
    </script>
<?php endif; ?>


    <h1>Machine Management</h1>
    <div>
        <h3>List of Machines</h3>
            <?php 
            require_once "D:/xampp/htdocs/www/WebSolution/inc/conn.inc.php";

            $refresh = "INSERT INTO machines (name) 
                        SELECT DISTINCT machine_name 
                        FROM machine_data 
                        WHERE NOT EXISTS (SELECT 1 FROM machines WHERE machines.name = machine_data.machine_name);";
                       

            mysqli_query($conn, $refresh);


            $sql = "SELECT * FROM machines WHERE in_use=1 ORDER BY name ASC;";
            
            if ($result = mysqli_query($conn, $sql)){
                if(mysqli_num_rows($result) > 0){
                    echo "<table>
                            <tr>
                            <th>Machine Name</th>
                            <th>Machine Description</th>
                            <th>Current Operator</th>
                            </tr>";
                    while ($row = mysqli_fetch_assoc($result)){
                        echo "<tr><td>$row[name]</td><td>$row[description]</td><td>$row[current_operator]</td></tr>";
                    }
                    echo "</table>";

                    mysqli_free_result($result);

                }

            }
        
            ?>
    </div>

    <div>
        <h3>Add New Machine</h3>
        <form action="add-machine.php" method="post">
            <label for="machine_name">Machine Name:</label>
            <input type="text" id="machine_name" name="machine_name" placeholder="Enter new machine name" required>
            <label for="machine_description">Machine Description:</label>
            <textarea id="machine_description" name="machine_description" placeholder="Enter a description of the machine" required></textarea>
            <label for="machine_operator">Assign Operator:</label>
            <select id="machine_operator" name="machine_operator" required>
            <option value="" disabled selected>Choose an operator</option>
                <?php   
                        require_once "C:/xampp/htdocs/www/WebSolution/inc/conn.inc.php";
                        $sql = "SELECT firstname, lastname FROM user_data WHERE is_operator=1 ORDER BY lastname ASC;";
                        if ($result = mysqli_query($conn, $sql)){
                            if(mysqli_num_rows($result) > 0){
                                while ($row = mysqli_fetch_assoc($result)){
                                    echo "<option value='{$row['firstname']} {$row['lastname']}'>{$row['firstname']} {$row['lastname']}</option>";
                                }
                                mysqli_free_result($result);
                            }
                            else {
                                echo "<option disabled>No operators found</option>";
                            }
                        }
                    
                ?>
            </select>

            <label for="initial_parameters">Initial Parameters:</label>
            <table id="initial_parameters">
                <tr>
                    <td><label for="temperature">Temperature</label></td>
                    <td><input type="number" id="temperature" name="temperature" value="0"></td>
                </tr>
                <tr>
                    <td><label for="pressure">Pressure</label></td>
                    <td><input type="number" id="pressure" name="pressure" value="0"></td>
                </tr>
                <tr>
                    <td><label for="vibration">Vibration</label></td>
                    <td><input type="number" id="vibration" name="vibration" value="0"></td>
                </tr>
                <tr>
                    <td><label for="humidity">Humidity</label></td>
                    <td><input type="number" id="humidity" name="humidity" value="0"></td>
                </tr>
                <tr>
                    <td><label for="power_consumption">Power Consumption</label></td>
                    <td><input type="number" id="power_consumption" name="power_consumption" value="0"></td>
                </tr>
                <tr>
                    <td><label for="operational_status">Operational Status</label></td>
                    <td>
                        <select id="operational_status" name="operational_status" required>
                            <option value="" disabled selected>Select status</option>
                            <option value="active">active</option>
                            <option value="idle">idle</option>
                            <option value="maintenance">maintenance</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><label for="production_count">Production Count</label></td>
                    <td><input type="number" id="production_count" name="production_count" value="0"></td>
                </tr>
                <tr>
                    <td><label for="speed">Speed</label></td>
                    <td><input type="number" id="speed" name="speed" value="0"></td>
                </tr>
            </table>

            <label for="machine_button"></label>
            <input type="submit" id="machine_button" value="Add Machine">
        </form>
    </div>

    <div>
        <h3>Remove Machine</h3>
        <form action="delete-machine.php" method="post">
            <label for="machine_name">Select Machine to Remove:</label>
            <select id="machine_name" name="machine_name" required>
                <option value="" disabled selected>Click to show machine list</option>
                <?php   
                        require_once "C:/xampp/htdocs/www/WebSolution/inc/conn.inc.php";
                        $sql = "SELECT * FROM machines WHERE in_use=1 ORDER BY name ASC;";
                        if ($result = mysqli_query($conn, $sql)){
                            if(mysqli_num_rows($result) > 0){
                                while ($row = mysqli_fetch_assoc($result)){
                                    echo "<option value='{$row['name']}'>{$row['name']}</option>";
                                }
                                mysqli_free_result($result);
                            }
                            else {
                                echo "<option disabled>No machines found</option>";
                            }
                        }
                    
                ?>
            </select>
            <label for="machine_button"></label>
            <input type="submit" id="machine_button" value="Remove Machine">
        </form>
    </div>

    <div>
        <h3>Update Machine</h3>
        <form id="adjust-machine" action="adjust-machine.php" method="post">
            <label for="machine_name">Select Machine to Update:</label>
            <select id="machine_name" name="machine_name" required>
                <option value="" disabled selected>Click to show machine list</option>
                <?php   
                        require_once "C:/xampp/htdocs/www/WebSolution/inc/conn.inc.php";
                        $sql = "SELECT * FROM machines WHERE in_use=1 ORDER BY name ASC;";
                        if ($result = mysqli_query($conn, $sql)){
                            if(mysqli_num_rows($result) > 0){
                                while ($row = mysqli_fetch_assoc($result)){
                                    echo "<option value='{$row['name']}'>{$row['name']}</option>";
                                }
                                mysqli_free_result($result);
                            }
                            else {
                                echo "<option disabled>No machines found</option>";
                            }
                        }
            
                ?>
            </select>
            <label for="machine_name_change">Adjust Name:</label>
            <input type="text" id="machine_name_change" name="machine_name_change" placeholder="Enter updated machine name">
            <label for="machine_description_change">Adjust Description:</label>
            <input type="textarea" id="machine_description_change" name="machine_description_change" placeholder="Enter updated description of the machine">
            <label for="machine_button"></label>
            <input type="submit" id="machine_button" value="Confirm adjustments">
        </form>
        <script defer>
            document.getElementById('adjust-machine').addEventListener('submit', function(event) {
            var name = document.getElementById('machine_name_change').value.trim();
            var description = document.getElementById('machine_description_change').value.trim();
            // Using trim for whitespace removal in case manager were to enter a space in any field accidentally.
                if (name == "" && description == "") {
                    alert('Please make at least one adjustment (name, description, or both) before updating the machine.');
                    event.preventDefault();
                    }
                }
            );
        </script>
    </div>
</body>
</html>