<?php

if (isset($_POST["machine_name"]) && isset($_POST["machine_description"]) && isset($_POST["machine_operator"])) {
    require_once "inc/conn.inc.php";
    $sql = "INSERT INTO machines(name, description, current_operator, in_use) VALUES(?, ?, ?, 1);";
    $statement = mysqli_stmt_init($conn);
    mysqli_stmt_prepare($statement, $sql); 
    mysqli_stmt_bind_param($statement, 'sss', $_POST["machine_name"], $_POST["machine_description"], $_POST["machine_operator"]);

    if (mysqli_stmt_execute($statement) == true){
        $sql_params = "INSERT INTO machine_data(timestamp, machine_name, temperature, pressure, vibration, humidity, power_consumption, operational_status, production_count, speed, error_code, maintenance_log) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '', '');";
        $statement_params = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement_params, $sql_params);
        $current_time = date('Y-m-d H:i:s');
        mysqli_stmt_bind_param($statement_params, 'ssdddddsdd', $current_time, $_POST["machine_name"], $_POST["temperature"], $_POST["pressure"], $_POST["vibration"], $_POST["humidity"], $_POST["power_consumption"], $_POST["operational_status"], $_POST["production_count"], $_POST["speed"]);
        
        if(mysqli_stmt_execute($statement_params) == true){
            header("location: machines.php?status=add-success"); 
        }
    }
    else{
        echo mysqli_error($conn);
    }
   
}

mysqli_close($conn);

?>
