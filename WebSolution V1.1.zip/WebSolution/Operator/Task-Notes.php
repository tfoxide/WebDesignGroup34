<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="../styles/diffstyle.css">
    <meta charset="UTF-8">
    <meta name="author" content="Xavier Curwood">
    <title>Task Notes</title>
</head>
<header>
    <h1>Task Notes</h1>
    <a href="Operator-Home.php" id='back-button'>
        <button>Back</button>
    </a>
</header>
<body>
<?php
    require_once "../inc/conn.inc.php";

//Check for button click
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //remove button
    if (isset($_POST['action']) && $_POST['action'] == 'delete_note') {
        $noteId = $_POST['note_id'];
        $deleteSql = "DELETE FROM TaskNotes WHERE NoteID = ?";
        $stmt = mysqli_prepare($conn, $deleteSql);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "i", $noteId);
            if (mysqli_stmt_execute($stmt)) {
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
            } 
            else {
                echo "<script>alert('Error deleting note: " . mysqli_error($conn) . "');</script>";
            }
            mysqli_stmt_close($stmt);
        } 
        else {
            echo "<script>alert('Error preparing statement: " . mysqli_error($conn) . "');</script>";
        }
    } 
    //add button
    else {
        // Get form data
        $comment = $_POST['comment'] ?? null; 
        $job = $_POST['job'] ?? null; 
        $receiver = $_POST['receiver'] ?? null; 
        $creator = 'SBartel01'; // TODO set up user control

        if ($comment && $job && $receiver) {
            $insertSql = "INSERT INTO TaskNotes (Note, Job, Creator, Receiver) VALUES (?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $insertSql);
            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "ssss", $comment, $job, $creator, $receiver);
                if (mysqli_stmt_execute($stmt)) {
                    header("Location: " . $_SERVER['PHP_SELF']);
                    exit();
                } 
                else {
                    echo "<script>alert('Error adding note: " . mysqli_error($conn) . "');</script>";
                }
                mysqli_stmt_close($stmt);
            } 
            else {
                echo "<script>alert('Error preparing statement: " . mysqli_error($conn) . "');</script>";
            }
        } 
        else {
            echo "<script>alert('All fields are required to add a note.');</script>";
        }
    }
}

//new notes form
echo "
    <form id='add-note' method='post'>
        <table>
            <tr>
                <th>Note</th>
                <th>Job</th>
                <th>Send to</th>
                <th></th>
            </tr>
            <tr>
                <td><textarea name='comment' form='add-note' id='new-note' required></textarea></td>
                <td><select name='job' id='note-select' required>
                    <option value='None'>None</option>";
                    // Fetch jobs
                    $jobSql = "SELECT job_code FROM jobs;";
                    $jobResult = mysqli_query($conn, $jobSql);
                    if ($jobResult) {
                        while ($jobRow = mysqli_fetch_assoc($jobResult)) {
                            echo "<option value='" . htmlspecialchars($jobRow['job_code']) . "'>" . htmlspecialchars($jobRow['job_code']) . "</option>";
                        }
                    }
                echo "</select> </td>
                <td><select name='receiver' id='note-select' required>";
                    // Fetch users
                    $userSql = "SELECT Username FROM user_data WHERE is_operator=1;";
                    $userResult = mysqli_query($conn, $userSql);
                    if ($userResult) {
                        while ($userRow = mysqli_fetch_assoc($userResult)) {
                            echo "<option value='" . htmlspecialchars($userRow['Username']) . "'>" . htmlspecialchars($userRow['Username']) . "</option>";
                        }
                    }
                echo "</select></td>
                <td><button type='submit'>Add</button></td>
            </tr>
        </table>
</form>";

$sql = "SELECT Note, Job, Creator, NoteID FROM TaskNotes;";

//Display all notes, and sort by job or Creator

if ($result = mysqli_query($conn, $sql)) {
    if (mysqli_num_rows($result) > 0) {
        echo "<table id='note-table'>";
        echo 
        "<tr>
            <th id='note-column'>Task Note</th>
            <th onclick='sortTable(1)' style='cursor:pointer;'>Job</th>
            <th onclick='sortTable(2)' style='cursor:pointer;'>Made By</th>
            <th>Remove</th>
        </tr>";

        // Fetch each rows data
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td id = 'note-column'>" . $row["Note"] . "</td>";
            echo "<td>" . $row["Job"] . "</td>";
            echo "<td>" . $row["Creator"] . "</td>";
            echo "<td>
                    <form method='post' style='display:inline;'>
                        <input type='hidden' name='action' value='delete_note'>
                        <input type='hidden' name='note_id' value='" . htmlspecialchars($row['NoteID']) . "'>
                        <button type='submit'>Remove</button>
                    </form>
                </td>";
            echo "</tr>";
        }
        echo "</table>";
        mysqli_free_result($result);    
    }
}

mysqli_close($conn);
    ?>
<script src="scripts/task-note-script.js"></script>
</body>
</html>
