<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Machine Management</title>
</head>
<body>
    <h1>Machine Management</h1>
    <div>
        <h2>List of Machines</h2>
        <ul id = machine-list>
            <?php 
            require_once "C:/xampp/htdocs/www/WebSolution/inc/conn.inc.php";
            $sql = "SELECT DISTINCT machine_name FROM machine_data;";
            
            if ($result = mysqli_query($conn, $sql)){
                if(mysqli_num_rows($result) > 0){
                    while ($row = mysqli_fetch_assoc($result)){
                        echo "<li>$row[machine_name]</li>";
                    }
                    mysqli_free_result($result);
                }
            }
            mysqli_close($conn);
            ?>
        </ul>
    </div>
    <h3>Add Machines</h3>
    <h3>Remove Machines</h3>
    <h3>Update Machines</h3>
</body>
</html>