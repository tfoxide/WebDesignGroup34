<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager Dashboard</title>
</head>
<body>
    <h1>Manager Dashboard</h1>
        <ul id="menu">
            <li><a href="">View factory operational status</a></li>
            <li><a href="machines.php">Machines</a></li>
            <li><a href="jobs.php">Jobs</a></li>
        </ul>
</body>
</html>
