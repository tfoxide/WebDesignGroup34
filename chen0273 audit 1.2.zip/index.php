<?php
require_once('Config/db.php');
$query = "select * from machine_data"; //not needed, machine data queried below
$results = mysqli_query($conn,$query);
include('Config/db.php'); //not needed, require_once above dies the same

?>

<!DOCTYPE html>
<html lang="en">


<head>
    <title>Web Solutions</title>
    <meta charset="UTF-8" />
    <meta name="Chen0273" content="width=device-width, initial-scale=1.0" />

</head> 

<body class="db-dark">

<form action method="post">
        
        
        
        <div>Notes: <input type="text"name="notes"><br></div>
        <div><input type="submit" name="save_notes" value="Submit"></div>
        



<?php
//$con = mysqli_connect("localhost","root","","websolutions");
$a=mysqli_query($conn,"select * from machines"); //using $conn as defined in db.php
?>
<select name="machine_name">
<?php
while($row = mysqli_fetch_assoc($a))
{
?>
    <option value="<?php echo $row['name']; ?>"><?php echo $row['name']; ?></option>
<?php
}
?>
</select>

</form>


<?php

if(isset($_POST['save_notes']))
{
print_r($_REQUEST);
$sql = "INSERT INTO audits(machine_name,notes) VALUES('" .$_POST['machine_name']."', '".$_POST['notes']."')";
$conn->query($sql);
}
?>






    <div class="containers">

    <form method="post">
       
     <input type="date" name ="search" value="<?php if(isset($_POST['search'])) echo $_POST['search']; ?>">
        <button class="btn" name="submit">Search</button>
	</form>
    <div class="container">
        <table class="table">

        <?php

        if(isset($_POST['search'])){
            $search=$_POST['search'];
            $searchstart=$search.'T00:00'; 
            $searchend=$search.'T23:59';
            
            $unixtimeStart= strtotime($searchstart);
            $unixtimeEnd= strtotime($searchend); //convert time to unix timestamp to be able to use for search which requires seconds.
            $fsearchStart = date('Y-m-d H:i:s', $unixtimeStart);
            $fsearchEnd = date('Y-m-d H:i:s', $unixtimeEnd);
           // echo $fsearch;
            $sql="select * from machine_data where timestamp>='$fsearchStart' and timestamp <='$fsearchEnd' ";
           // echo $sql; // testing the data retrieved
            //$results=mysqli_query($conn,$sql);
            
            /*if ($result){
            if(mysqli_num_rows($result)>0){
                echo '<thead>
                <tr>
                <th>title test</th>
                <th>Test one</th>
                <th>Test two</th>
                </tr>
                </thead> 
                ';
                
                while($row=mysqli_fetch_assoc($result)){
                echo '<tbody>
                <tr>
                <td>'.$row['maintenance_log'].'</td>
                <td>'.$row['timestamp'].'</td>
                <td>'.$row['machine_name'].'</td>
                </tr>
                </tbody>';
            }
            }else {
                echo '<h2 class=text> No data found</h2>';}*/
            
            
            //$num=mysqli_num_rows($results);
            //echo $num

            }
            else {
                $sql = "select * from machine_data";
            }

            $results=mysqli_query($conn,$sql);



        ?>
       </div>
    </div>

   


</form>


    
    <div class="container">
        <div class="row mt-5">
         <div class="col">
          <div class="card mt-5">
           <div class="card-header">
             <h2 class="display-6 text-center">Auditor report Review</h2>

            </div>
           </div>
          </div>
         </div>
        </div>
    <div class="card-body">

<?php if(mysqli_num_rows($results)>0){ ?>   


    <table class="table table-bordered">
    <tr class="bg-dark text-white">
    <td><b> Timestamp</b> </td>
    <td><b> machine_name</b> </td>
    <td><b> Temperature</b> </td>
    <td><b> Pressure</b> </td>
    <td><b> vibration</b> </td>
    <td><b> Humidity</b> </td>
    <td><b> Power_consumption</b> </td>
    <td><b> operational_status</b> </td>
    <td><b> error_code</b> </td>
    <td><b> production_count</b> </td>
    <td><b> mainteneance_log</b> </td>
    <td><b> speed</b> </td>
  
    </tr>
    
   
    <?php
    
    while($row = mysqli_fetch_assoc($results))
    {
  ?> <tr>
  <td><?php echo $row['timestamp']; ?></td>
  <td><?php echo $row['machine_name']; ?></td>
  <td><?php echo $row['temperature']; ?></td>
  <td><?php echo $row['pressure']; ?></td>
  <td><?php echo $row['vibration']; ?></td>
  <td><?php echo $row['humidity']; ?></td>
  <td><?php echo $row['power_consumption']; ?></td>
  <td><?php echo $row['operational_status']; ?></td>
  <td><?php echo $row['error_code']; ?></td>
  <td><?php echo $row['production_count']; ?></td>
  <td><?php echo $row['maintenance_log']; ?></td>
  <td><?php echo $row['speed']; ?></td>
  
    </tr>
    <?php
    }



    ?>
</table>
<?php } else { ?>  
    <h2>No data found</h2>
<?php } ?>
</body>
</html>