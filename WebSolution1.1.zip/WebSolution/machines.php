<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Machine Management</title>
    <link rel="stylesheet" href="styles/style.css"/>
</head>
<body>
    <h1>Machine Management</h1>
    <div>
        <h2>List of Machine Types</h2>
        <ul id = machine-list>
            <?php 
            require_once "C:/xampp/htdocs/www/WebSolution/inc/conn.inc.php";

            $refresh = "INSERT INTO machines (name) 
                        SELECT DISTINCT machine_name 
                        FROM machine_data 
                        WHERE NOT EXISTS (SELECT 1 FROM machines WHERE machines.name = machine_data.machine_name);";
                       

            mysqli_query($conn, $refresh);

            $updateUseStatus = "UPDATE machines 
                                SET in_use = 1 
                                WHERE name IN (SELECT DISTINCT machine_name FROM machine_data);";

            mysqli_query($conn, $updateUseStatus);

            $sql = "SELECT * FROM machines ORDER BY name ASC;";
            
            if ($result = mysqli_query($conn, $sql)){
                if(mysqli_num_rows($result) > 0){
                    while ($row = mysqli_fetch_assoc($result)){
                        $inUse = $row['in_use'] ? ' (in factory)' : '';
                        echo "<li>$row[name]$inUse</li>";
                        if($row['description']){
                            echo "<span style='color: gray; font-style: italic; font-size: 18px; padding: 20px;'>{$row['description']}</span>";
                        }
                    }
                    mysqli_free_result($result);
                }

            }
        
            mysqli_close($conn);
            ?>
        </ul>
    </div>

    <div>
        <h3>Add New Machine Type</h3>
        <form action="add-machine.php" method="post">
            <label for="machine_name">Machine Name:</label>
            <input type="text" id="machine_name" name="machine_name" placeholder="Enter new machine name" required>
            <label for="machine_description">Machine Description:</label>
            <input type="textarea" id="machine_description" name="machine_description" placeholder="Enter a description of the machine">
            <label for="machine_button"></label>
            <input type="submit" id="machine_button" value="Add Machine">
        </form>
    </div>

    <div>
        <h3>Remove Machines</h3>
    </div>

    <div>
        <h3>Update Machines</h3>
    </div>
</body>
</html>