<?php
$conn = mysqli_connect("localhost", "dbadmin", "", "factory_logs");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>