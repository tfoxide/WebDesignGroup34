<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../Styles/style.css?v=1.1">
    <meta charset="UTF-8">
    <meta name="author" content="Xavier Curwood">
    <title>Operator</title>
</head>
<header>
    <h1>Operator Menu</h1>
    <a href="../login.html" id='back-button'>
        <button>Logout</button>
    </a>
</header>
<body>
    <div>
        <p id='welcome'>Welcome SBartel01</p> <!--TODO make user a variable -->
    </div>
    <table id="operator-menu">
        <tr>
            <th>Menu</th>
        </tr>
        <tr>
            <td>
                <a href="Jobs/Job-List.php">
                    <button id='base-button'>Jobs</button>
                </a>
                <a href="Machines/machine-home.html"> <!-- TODO Replace with machine page -->
                    <button id='base-button'>Machines</button>
                </a>
                <a href="Task-Notes.php">
                    <button id='base-button'>Task Notes</button>
                </a>
            </td>
    </table>
</body>
</html>