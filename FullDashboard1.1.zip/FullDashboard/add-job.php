<?php

session_start();
$currentUsername = $_SESSION['username'] ?? null;    
if (isset($_POST["job_name"]) && isset($_POST["job_code"])  && isset($_POST["job_machine"]) && isset($_POST["job_operator"]) && isset($_POST["job_description"])){
    require_once "inc/conn.inc.php";
    $sql = "INSERT INTO jobs(name, job_code, machine, assigned_to, description, active, status) VALUES(?, ?, ?, ?, ?, 1, 'Paused');";
    $statement = mysqli_stmt_init($conn);
    mysqli_stmt_prepare($statement, $sql); 
    mysqli_stmt_bind_param($statement, 'sssss', $_POST["job_name"], $_POST["job_code"], $_POST["job_machine"], $currentUsername, $_POST["job_description"]);
    if (mysqli_stmt_execute($statement) == true){
        header("location: jobs.php?status=add-success"); 
    }
    else{
        echo mysqli_error($conn);
    }
   
}

mysqli_close($conn);

?>