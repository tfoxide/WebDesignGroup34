function sortTable2(columnIndex) {
    const table = document.getElementById("monitor-table");
    const rows = Array.from(table.rows).slice(1);
    const sortedRows = rows.sort((a, b) => {
        const aText = a.cells[columnIndex].innerText;
        const bText = b.cells[columnIndex].innerText;
        return bText.localeCompare(aText);
    });
     
    // Append sorted rows back to the table
    sortedRows.forEach(row => table.appendChild(row));
    }
