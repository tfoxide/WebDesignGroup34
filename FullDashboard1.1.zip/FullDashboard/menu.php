<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager Dashboard</title>
    <link rel="stylesheet" href="styles/style.css"/>
</head>
<body>
    <h1 style="text-align: center;">Manager Menu</h1>
            <?php 
                session_start();
                include_once "C:/xampp/htdocs/www/WebSolution/inc/conn.inc.php";
                if (isset($_SESSION['username'])) {
                    $sql = "SELECT firstname FROM user_data WHERE username = ?;";
                    $statement = mysqli_stmt_init($conn);
                    mysqli_stmt_prepare($statement, $sql);
                    mysqli_stmt_bind_param($statement, 's', $_SESSION['username']);
                    mysqli_stmt_execute($statement);
                    $result = mysqli_stmt_get_result($statement);
                    $row = mysqli_fetch_assoc($result);

                    if ($row) {
                        echo "<h2 style='font-size: 34px; text-align: center;'>Welcome, " . htmlspecialchars($row['firstname']) . "</h2>";
                    }

                } 
            ?>

    <div class="menu">
        <h3><a href="./Operator/Monitor-Performance.php">View factory operational status</a></h3>
        <h3><a href="machines.php">Edit Machines</a></h3>
        <h3><a href="jobs.php">Edit Jobs</a></h3>
    </div>    

</body>
</html>
