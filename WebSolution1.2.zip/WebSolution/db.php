<?php
    $conn = mysqli_connect("localhost","root","","websolutions");

    if(!$conn){
        die("Connection Error");
    }


?>