<?php
require_once "inc/conn.inc.php";
if (isset($_POST["user"])) {
    $userFullName = $_POST["user"];
    $nameParts = explode(" ", $userFullName);
    $firstNameOld = $nameParts[0];
    $lastNameOld = $nameParts[1]; 
    $firstName = $_POST["fname"];
    $lastName = $_POST["lname"];
    $role = $_POST["role"];
    $is_admin = 0;
    $is_manager = 0;
    $is_operator = 0;
    $is_auditor = 0;

    if($role == "administrator"){
        $is_admin = 1;
    }
    if($role == "manager"){
        $is_manager = 1;
    }
    if($role == "operator"){
        $is_operator = 1;
    }
    if($role == "auditor"){
        $is_auditor = 1;
    }

    if (!empty($firstName) && !empty($lastName) && !empty($role)) {
        $sql = "UPDATE user_data SET firstname=?, lastname=?, is_admin = $is_admin, is_manager = $is_manager, is_operator = $is_operator, is_auditor = $is_auditor WHERE firstname=? AND lastname=?;";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql);
        mysqli_stmt_bind_param($statement, 'ssss', $firstName, $lastName, $firstNameOld, $lastNameOld);
        if (mysqli_stmt_execute($statement)) {
            header("location: menu-admin.php?status=adjust-success");
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
        
    }

    if (!empty($firstName) && !empty($lastName) && empty($role)) {
        $sql = "UPDATE user_data SET firstname=?, lastname=? WHERE firstname=? AND lastname=?;";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql);
        mysqli_stmt_bind_param($statement, 'ssss', $firstName, $lastName, $firstNameOld, $lastNameOld);
        if (mysqli_stmt_execute($statement)) {
            header("location: menu-admin.php?status=adjust-success");
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
    }

    if(!empty($firstName) && empty($lastName) && empty($role)) {
        $sql = "UPDATE user_data SET firstname=? WHERE firstname=? AND lastname=?;";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql);
        mysqli_stmt_bind_param($statement, 'sss', $firstName, $firstNameOld, $lastNameOld);
        if (mysqli_stmt_execute($statement)) {
            header("location: menu-admin.php?status=adjust-success");
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
    }

    if(empty($firstName) && !empty($lastName) && empty($role)) {
        $sql = "UPDATE user_data SET lastname=? WHERE firstname=? AND lastname=?;";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql);
        mysqli_stmt_bind_param($statement, 'sss', $lastName, $firstNameOld, $lastNameOld);
        if (mysqli_stmt_execute($statement)) {
            header("location: menu-admin.php?status=adjust-success");
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
    }

    if(empty($firstName) && empty($lastName) && !empty($role)) {
        $sql = "UPDATE user_data SET is_admin = $is_admin, is_manager = $is_manager, is_operator = $is_operator, is_auditor = $is_auditor WHERE firstname=? AND lastname=?;";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql);
        mysqli_stmt_bind_param($statement, 'ss', $firstNameOld, $lastNameOld);
        if (mysqli_stmt_execute($statement)) {
            header("location: menu-admin.php?status=adjust-success");
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
    }

    if(empty($firstName) && !empty($lastName) && !empty($role)) {
        $sql = "UPDATE user_data SET lastname=?, is_admin = $is_admin, is_manager = $is_manager, is_operator = $is_operator, is_auditor = $is_auditor WHERE firstname=? AND lastname=?;";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql);
        mysqli_stmt_bind_param($statement, 'sss', $lastName, $firstNameOld, $lastNameOld);
        if (mysqli_stmt_execute($statement)) {
            header("location: menu-admin.php?status=adjust-success");
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }

    }

    if(!empty($firstName) && empty($lastName) && !empty($role)) {
        $sql = "UPDATE user_data SET firstname=?, is_admin = $is_admin, is_manager = $is_manager, is_operator = $is_operator, is_auditor = $is_auditor WHERE firstname=? AND lastname=?;";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql);
        mysqli_stmt_bind_param($statement, 'sss', $firstName, $firstNameOld, $lastNameOld);
        if (mysqli_stmt_execute($statement)) {
            header("location: menu-admin.php?status=adjust-success");
            exit();
        } else {
            echo mysqli_error($conn);
            echo mysqli_stmt_error($statement);
        }
    }


}
    mysqli_close($conn);
?>