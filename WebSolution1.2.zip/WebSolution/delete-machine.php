<?php

    if (isset($_POST["machine_name"])) {
        require_once "inc/conn.inc.php";
        $sql = "UPDATE machines SET in_use=0 WHERE name=?;";
        $statement = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($statement, $sql); 
        mysqli_stmt_bind_param($statement, 's', $_POST["machine_name"]);
        if (mysqli_stmt_execute($statement) == true){
            header("location: machines.php?status=remove-success"); 
        }
        else{
            echo mysqli_error($conn);
            echo mysqli_stmt_error($conn);
        }
    }

    mysqli_close($conn);

?>