<?php

if (isset($_POST["machine_name"]) || (($_POST["machine_name"]) && ($_POST["machine_description"]))) {
    require_once "inc/conn.inc.php";
    $sql = "INSERT INTO machines(name, description, in_use) VALUES(?, ?, 1);";
    $statement = mysqli_stmt_init($conn);
    mysqli_stmt_prepare($statement, $sql); 
    mysqli_stmt_bind_param($statement, 'ss', $_POST["machine_name"], $_POST["machine_description"]);
    if (mysqli_stmt_execute($statement) == true){
        header("location: machines.php?status=add-success"); 
    }
    else{
        echo mysqli_error($conn);
    }
   
}

mysqli_close($conn);

?>