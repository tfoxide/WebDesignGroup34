<?php
    if(isset($_POST["hash"])){
        echo password_hash($_POST["hash"], PASSWORD_DEFAULT);
    }
?> 