<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Login</title>
    <link rel = "stylesheet" href = "styles/style.css"/>
</head>
<body>
    <h1 style="text-align: center;">Smart Manufacturing Dashboard Login</h1>
    <form style="margin: auto;" action="login-process.php" method="post">
        <label for="username" style="font-weight: bold;">Username:</label><br>
        <input type="text" id="username" name="username" required><br>
        <label for="password" style="font-weight: bold;">Password:</label><br>
        <input type="password" id="password" name="password" required><br> 
        <button type="submit">Login</button>
    </form>
    <!-- <form style="margin: auto;" action="hash.php" method="post">
        <input type="text" id="hash" name="hash" required><br>
        
        <button type="submit">Hash</button>
    </form> -->
</body>
</html>