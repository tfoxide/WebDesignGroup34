<?php
    require_once('inc\conn.inc.php');
    $query = "select * from machine_data"; //not needed, machine data queried below
    $results = mysqli_query($conn,$query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Web Solutions</title>
    <meta charset="UTF-8" />
    <meta name="Chen0273" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="styles/style.css" />
    <style>
        form {
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #f9f9f9;
            font-size: 20px;
        }

        select, input[type="text"], button {
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="date"]{
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        label {
            margin-top: 10px;
            display: block;
            font-weight: bold;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .btn {
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #218838;
        }
    </style>
</head> 

<body class="db-dark">
<button id="menu_button" style="position: fixed; left: 20px; top: 20px; font-size: 30px; background-color: #007bff; color: #fff; border: black 2px solid; padding: 10px 20px; border-radius: 5px; cursor: pointer;">
    <a href="login.php" style="color: #fff; text-decoration: none;">Logout</a>
</button>

    <form action method="post">

        <?php
            $a=mysqli_query($conn,"select * from machines"); //using $conn 
        ?>

        <label>Choose a machine to add notes for:</label>
        <select name="machine_name">
        <?php
            while($row = mysqli_fetch_assoc($a))
        {
        ?>
        <option value="<?php echo $row['name']; ?>"><?php echo $row['name']; ?></option>
        <?php
        }
        ?>
        </select>

        <label for="notes">Add notes:</label>
        <input type="text"name="notes"id="notes"><br> 
        <input class="btn" type="submit" name="save_notes" value="Submit"></div>

    </form>

<?php

if(isset($_POST['save_notes']))
{
print_r($_REQUEST);
$sql = "INSERT INTO audits(machine_name, notes) VALUES('" .$_POST['machine_name']."', '".$_POST['notes']."')";
$conn->query($sql);
}
?>
    <form method="post">
    <label>Search data by date:</label>    
    <input type="date" name ="search" value="<?php if(isset($_POST['search'])) echo $_POST['search']; ?>">
        <button class="btn" name="submit">Search</button>
	</form>

    <div>
        <?php
        if(isset($_POST['search'])){
            $search=$_POST['search'];
            $searchstart=$search.'T00:00'; 
            $searchend=$search.'T23:59';
            
            $unixtimeStart= strtotime($searchstart);
            $unixtimeEnd= strtotime($searchend); //convert time to unix timestamp to be able to use for search which requires seconds.
            $fsearchStart = date('Y-m-d H:i:s', $unixtimeStart);
            $fsearchEnd = date('Y-m-d H:i:s', $unixtimeEnd);
    
            $sql="select * from machine_data where timestamp>='$fsearchStart' and timestamp <='$fsearchEnd' ";

            }
            else {
                $sql = "select * from machine_data";
            }

            $results=mysqli_query($conn,$sql);



        ?>
    </div>
</form>
    

<h2 class="display-6 text-center">Auditor Report Review</h2>
          
<div class="card-body">

<?php if(mysqli_num_rows($results)>0){ ?>   


    <table class="table-bordered">
    <tr>
    <td><b> Timestamp</b> </td>
    <td><b> Machine Name</b> </td>
    <td><b> Temperature</b> </td>
    <td><b> Pressure</b> </td>
    <td><b> Vibration</b> </td>
    <td><b> Humidity</b> </td>
    <td><b> Power Consumption</b> </td>
    <td><b> Operational Status</b> </td>
    <td><b> Error Code</b> </td>
    <td><b> Production Count</b> </td>
    <td><b> Maintenance Log</b> </td>
    <td><b> Speed</b> </td>
    </tr>
    
    <?php
    
    while($row = mysqli_fetch_assoc($results))
    {
    ?> <tr>
        <td><?php echo $row['timestamp']; ?></td>
        <td><?php echo $row['machine_name']; ?></td>
        <td><?php echo $row['temperature']; ?></td>
        <td><?php echo $row['pressure']; ?></td>
        <td><?php echo $row['vibration']; ?></td>
        <td><?php echo $row['humidity']; ?></td>
        <td><?php echo $row['power_consumption']; ?></td>
        <td><?php echo $row['operational_status']; ?></td>
        <td><?php echo $row['error_code']; ?></td>
        <td><?php echo $row['production_count']; ?></td>
        <td><?php echo $row['maintenance_log']; ?></td>
        <td><?php echo $row['speed']; ?></td>
    </tr>
    <?php
    }



    ?>
    </table>
<?php } else { ?>  
    <h2>No data found</h2>
<?php } ?>
</body>
</html>