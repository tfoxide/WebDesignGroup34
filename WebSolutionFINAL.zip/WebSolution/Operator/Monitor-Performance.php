<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Xavier Curwood">
    <title>Factory Performance</title> 
    <link rel="stylesheet" href="../styles/diffstyle.css?v1.3">
</head>
<header>
    <h1>Overall Factory Performance</h1>
    <?php 
        session_start();
        include_once "../inc/conn.inc.php";
        if (isset($_SESSION['username'])) {
            $sql = "SELECT * FROM user_data WHERE username = ?;";
            $statement = mysqli_stmt_init($conn);
            mysqli_stmt_prepare($statement, $sql);
            mysqli_stmt_bind_param($statement, 's', $_SESSION['username']);
            mysqli_stmt_execute($statement);
            $result = mysqli_stmt_get_result($statement);
            $row = mysqli_fetch_assoc($result);

            if ($row['is_admin'] == 1) {
                echo "<a href='../menu-admin.php' id='back-button'>";
                echo "<button>Back</button></a>";
            }

            if ($row['is_manager'] == 1) {
                echo "<a href='../menu.php' id='back-button'>";
                echo "<button>Back</button></a>";
            }

            if ($row['is_operator'] == 1) {
                echo "<a href='../Operator/Operator-Home.php' id='back-button'>";
                echo "<button>Back</button></a>";
            }

            if ($row['is_auditor'] == 1) {
                echo "<a href='../auditor.php' id='back-button'>";
                echo "<button>Back</button></a>";
            }

        } 
    ?>
</header>
<body>
    <h2>Jobs</h2>
<?php

$sql = "SELECT job_code, name, assigned_to, status FROM jobs;";

//find jobs for user
if ($result = mysqli_query($conn, $sql)) {
    if (mysqli_num_rows($result) > 0) {
        echo "<table id='note-table'>";
        echo 
        "<tr>
            <th id='number-column' onclick='sortTable(0)' style='cursor:pointer;'>Code</th>
            <th>Name</th>
            <th onclick='sortTable(2)' style='cursor:pointer;'>Status</th>
            <th onclick='sortTable(3)' style='cursor:pointer;'>Assigned To</th>
        </tr>";
        // Fetch each rows data
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td id='number-column'>" . $row["job_code"] . "</td>";
            echo "<td>" . $row["name"] . "</td>";
            echo "<td>" . $row["status"] . "</td>";
            echo "<td>" . $row["assigned_to"] . "</td>";
        }
        echo "</table>";
        mysqli_free_result($result);
    }
}

echo "<h2>Machines</h2>";
$sql = "
    SELECT timestamp, machine_name, operational_status, error_code, maintenance_log
    FROM machine_data AS m1
    WHERE timestamp = (
        SELECT MAX(timestamp)
        FROM machine_data AS m2
        WHERE m1.machine_name = m2.machine_name
    );
";

//find jobs for user
if ($result = mysqli_query($conn, $sql)) {
    if (mysqli_num_rows($result) > 0) {
        echo "<table id='monitor-table'>";
        echo 
        "<tr>
            <th onclick='sortTable2(0)' style='cursor:pointer;'>Time</th>
            <th onclick='sortTable2(1)' style='cursor:pointer;'>Machine</th>
            <th onclick='sortTable2(2)' style='cursor:pointer;'>Status</th>
            <th onclick='sortTable2(3)' style='cursor:pointer;'>Error Code</th>
            <th>Maintenance Log</th>
        </tr>";
        // Fetch each rows data
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row["timestamp"] . "</td>";
            echo "<td>" . $row["machine_name"] . "</td>";

            // Determine status
            $statusClass = '';
            if ($row["operational_status"] == 'active') {
                $statusClass = 'status-active';
            } elseif ($row["operational_status"] == 'idle') {
                $statusClass = 'status-idle';
            } elseif ($row["operational_status"] == 'maintenance') {
                $statusClass = 'status-maintenance';
            }
            // Change colour accordingly
            echo "<td>
                <span class='machine-status-circle $statusClass'> ". $row["operational_status"] ." </span>
            </td>";

            echo "<td>" . $row["error_code"] . "</td>";
            echo "<td>" . $row["maintenance_log"] . "</td>";
        }
        echo "</table>";
        mysqli_free_result($result);
    }
}

mysqli_close($conn);
    ?>
<script src="scripts/task-note-script.js"></script>
<script src="scripts/monitor-script.js"></script>
</body>
</html>