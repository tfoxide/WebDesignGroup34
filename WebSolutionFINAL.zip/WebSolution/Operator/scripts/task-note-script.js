
function sortTable(columnIndex) {
    const table = document.getElementById("note-table");
    const rows = Array.from(table.rows).slice(1);
    const sortedRows = rows.sort((a, b) => {
        const aText = a.cells[columnIndex].innerText;
        const bText = b.cells[columnIndex].innerText;
        return aText.localeCompare(bText);
    });
     
    // Append sorted rows back to the table
    sortedRows.forEach(row => table.appendChild(row));
    }
