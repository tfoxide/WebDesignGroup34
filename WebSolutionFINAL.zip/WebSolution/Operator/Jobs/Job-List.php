<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../../styles/diffstyle.css?v=1.2">
    <meta charset="UTF-8">
    <meta name="author" content="Xavier Curwood">
    <title>Job List</title>
</head>
<header>
    <h1>Job List</h1>
    <a href="../Task-Notes.php" id='back-button'>
        <button>Task Notes</button>
    </a>
    <a href="../Operator-Home.php" id='back-button'>
        <button>Back</button>
    </a>
</header>
<body>
<?php
    require_once "../../inc/conn.inc.php";
    session_start();
    // Function to toggle status
    function toggleStatus($currentStatus) {
        if ($currentStatus == "Paused") {
            return "In Progress";
        } 
        elseif ($currentStatus == "In Progress") {
            return "Paused";
        }
        return "Error";
    }

    //Check for toggle
    if (isset($_POST['toggle'])) {
        $code = $_POST['job_code'];
        $currentStatus = $_POST['current_status'];
        $machine = $_POST['Machine'];

        $newStatus = toggleStatus($currentStatus);
        
        
        // Update the job status in the database
        $updateSql = "UPDATE jobs SET status='$newStatus' WHERE job_code='$code'";
        if (!mysqli_query($conn, $updateSql)) {
            echo "Error updating job status: " . mysqli_error($conn);
        } else {
            header("Location: Job-List.php");
            exit();
        }
 
    }
     // Check for finish
     if (isset($_POST['finish'])) {
        $code = $_POST['job_code'];

        // Set active status to 0
        $finishSql = "UPDATE jobs SET active=0 WHERE job_code='$code'";
        if (!mysqli_query($conn, $finishSql)) {
            echo "Error finishing job: " . mysqli_error($conn);
        } else {
            header("Location: Job-List.php");
            exit();
        }
    }

    $currentUsername = $_SESSION['username'] ?? null;
    $sql = "SELECT job_code, name, description, status, machine, active FROM jobs WHERE assigned_to='$currentUsername' AND active=1;"; #TODO make assigneduser a variable and check for login
    
//find jobs for user
if ($result = mysqli_query($conn, $sql)) {
    if (mysqli_num_rows($result) > 0) {
        echo "<table>";
        echo 
        "<tr>
            <th id='number-column'>Code</th>
            <th>Name</th>
            <th>Details</th>
            <th>Machine</th>
            <th>Status</th>
            <th>Complete</th>
        </tr>";
        //Fetch row data
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td id='number-column'>" . $row["job_code"] . "</td>";
            echo "<td>" . $row["name"] . "</td>";
            echo "<td>" . $row["description"] . "</td>";
            echo "<td>" . $row["machine"] . "</td>";

            //change colour according to status
            $statusClass = $row["status"] == 'In Progress' ? 'status-in-progress' : 'status-paused';

            //Start/Stop Button
            echo "  <td>
                        <form method='post' action=''>
                            <input type='hidden' name='job_code' value='" . $row["job_code"] . "' />
                            <input type='hidden' name='current_status' value='" . $row["status"] . "' />
                            <input type='hidden' name='Machine' value='" . $row["machine"] . "' />
                            <button type='submit' name='toggle' class='status-circle $statusClass'>
                                " . $row["status"] . "
                            </button>
                        </form>
                    </td>";

            //Finish button
            echo "<td>
                <form method='post' action=''>
                    <input type='hidden' name='job_code' value='" . $row["job_code"] . "' />
                    <button type='submit' name='finish' class='finish-button'>Finish</button>
                </form>
              </td>";
        }
        echo "</table>";
        mysqli_free_result($result);
    }
    else {
        echo "<h2>No jobs found</h2>";
    }
}

mysqli_close($conn);
    ?>
</body>
</html>