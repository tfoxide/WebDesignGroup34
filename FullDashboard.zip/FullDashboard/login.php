<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Login</title>
    <link rel = "stylesheet" href = "styles/style.css"/>
</head>
<body>
    <?php
    $status = isset($_GET['status']) ? $_GET['status'] : '';

    // Error message for invalid login
    if ($status == 'login-failed'): ?>
        <div style="color: white; font-size: 18px; padding: 10px; border: 1px solid green; background-color: #d66565;">
            <?php 
                echo 'Invalid username or password';
            ?>
        </div>
    <?php endif; ?>

    <!-- Timeout for error message -->
    <script>
        setTimeout(function() {
            document.querySelector('div[style="color: white; font-size: 18px; padding: 10px; border: 1px solid green; background-color: #d66565;"]').style.display = 'none';
        }, 3000);
    </script>

    <h1 style="text-align: center;">Smart Manufacturing Dashboard Login</h1>
    <div class="login-form">
        <form action="login-process.php" method="post">
            <label for="username" style="font-weight: bold;">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password" style="font-weight: bold;">Password:</label>

            <div class="password-pair">
                <input style="width: 400px;" type="password" id="password" name="password" required>
                <button id="see-password">&#128065;</button>
            </div>

            <input id="login-button" value="Log-in" type="submit">
            
        </form>
    </div>

    <!-- Script for Password Show/Hide Functionality -->
    <script>
        document.getElementById('see-password').addEventListener('click', () => {
                event.preventDefault();
                var passwordField = document.getElementById('password');
                var seeButton = document.getElementById('see-password');
                if (passwordField.type == 'password') {
                    passwordField.type = 'text';
                    seeButton.style.backgroundColor = '#7a7b7d';
                } else {
                    passwordField.type = 'password';
                    seeButton.innerHTML = '&#128065;';
                    seeButton.style.backgroundColor = '';
                }
            }
        );
        document.getElementById('password').addEventListener('keydown', (event) => {
        if (event.key == 'Enter') {
            event.preventDefault();
            document.getElementById('login-button').click();   
            }
        });
    </script>    
</body>
</html>

